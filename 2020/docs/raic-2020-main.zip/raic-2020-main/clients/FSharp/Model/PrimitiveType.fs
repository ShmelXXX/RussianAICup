#nowarn "0058"
namespace Aicup2020.Model
type PrimitiveType =
    | Lines = 0
    | Triangles = 1
