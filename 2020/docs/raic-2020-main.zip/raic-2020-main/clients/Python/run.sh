set -ex

cd /output
python ./main.py "$@"