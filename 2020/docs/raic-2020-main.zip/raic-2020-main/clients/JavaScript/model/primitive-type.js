module.exports = {
    Lines : 0,
    Triangles : 1
}
