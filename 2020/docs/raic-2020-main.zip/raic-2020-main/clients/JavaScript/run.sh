set -ex

cd /output
node ./index.js "$@"