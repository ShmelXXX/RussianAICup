set -ex

cd /output
dotnet ./aicup2020.dll "$@"