set -ex

cd /output
jruby ./main.rb "$@"