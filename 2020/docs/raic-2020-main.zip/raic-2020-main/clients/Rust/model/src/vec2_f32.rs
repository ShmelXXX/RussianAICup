use super::*;
#[derive(Clone, Debug, trans::Trans)]
pub struct Vec2F32 {
    pub x: f32,
    pub y: f32,
}
