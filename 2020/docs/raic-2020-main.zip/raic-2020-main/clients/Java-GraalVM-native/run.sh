set -ex

cd /output
./aicup2020-native-with-dependencies "$@"