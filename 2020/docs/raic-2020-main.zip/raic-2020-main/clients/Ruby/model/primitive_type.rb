module PrimitiveType
    LINES = 0
    TRIANGLES = 1
end
