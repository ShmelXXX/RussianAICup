namespace Aicup2020.Model
{
    public enum PrimitiveType
    {
        Lines = 0,
        Triangles = 1,
    }
}
