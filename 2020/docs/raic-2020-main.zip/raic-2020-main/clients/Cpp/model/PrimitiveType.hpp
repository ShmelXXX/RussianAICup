#ifndef _MODEL_PRIMITIVE_TYPE_HPP_
#define _MODEL_PRIMITIVE_TYPE_HPP_

#include "../Stream.hpp"

enum PrimitiveType {
    LINES = 0,
    TRIANGLES = 1
};

#endif
