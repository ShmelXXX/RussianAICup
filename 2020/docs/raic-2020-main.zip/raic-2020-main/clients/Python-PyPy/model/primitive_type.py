from enum import IntEnum

class PrimitiveType(IntEnum):
    LINES = 0
    TRIANGLES = 1
