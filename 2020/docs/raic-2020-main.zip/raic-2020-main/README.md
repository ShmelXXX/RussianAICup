# AI CUP 2020 - CodeCraft

- [Changelog](CHANGELOG.md) | [Список изменений](CHANGELOG-ru.md)
- [Documentation](doc-en.md) | [Документация](doc-ru.md)
- [Clients (with Dockerfiles)](clients)