set -ex

cd /output
pypy3 ./main.py "$@"