use super::*;
#[derive(Clone, Debug, PartialEq, Eq, Hash, trans::Trans)]
pub struct Vec2I32 {
    pub x: i32,
    pub y: i32,
}
